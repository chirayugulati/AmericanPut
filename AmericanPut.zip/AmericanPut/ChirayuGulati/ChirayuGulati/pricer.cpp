 //
// Created by ChirayuGulati on 22/02/2022.
//

#include <cmath>
#include <iostream>
#include <string>
#include <vector>
#include "prices.h"


int main ()
{
    // This is the part used to launch the software which estimates the fair price of American put options
    cout << "American puts" << endl;

    AmericanPut test1(50.0,81.0,.4,1.0,.01);

    double P1 = test1.getValue();

    cout << "Test Values" << endl;
    cout << "Put Fair Value = " << P1 << endl;


    system("pause");
    return 0;
}












// below we have the definition of the generic Equity class and its methods
Equity::Equity(void) : Asset()
{
}
Equity::~Equity( void )
{
}
double Equity::getValue()
{
    return EquityPrice;
}
void Equity::setValue(double price)
{
    EquityPrice = price;
}

// below we have the definition of the generic Option class and its methods
Option::Option( double strike0, double spot0, double sigma, double Time, double rate ) : Asset()
{
    //  Set basic parameters
    strike = strike0;
    spot = spot0;
    volatility = sigma;
    T = Time;
    r = rate;
    nowEquity.setValue( spot0 );



    d1 = calc_d1(nowEquity,strike,r,volatility,T);
    d2 = calc_d2(nowEquity,strike,r,volatility,T);
}
Option::~Option()
{
    //  Nothing to delete
}
double Option::calc_d1(Equity& S, double K, double r, double vix, double T)
{
    return ( log(S.getValue()/K) + (r + .5*vix*vix)*T ) / (vix*sqrt(T));
}

double Option::calc_d2(Equity& S, double K, double r, double vix, double T)
{
    return ( log(S.getValue()/K) + (r - .5*vix*vix)*T ) / (vix*sqrt(T));
}






double Option::getSpot(){ return spot; } //  use the Equity class
double Option::getVolatility(){ return volatility; }
double Option::getTime(){ return T; }
double Option::getRate(){ return r; }




// below we have the definition of the generic American put class and its methods
AmericanPut::AmericanPut( double strike0, double spot0, double sigma, double Time, double rate ) : Option( strike0,  spot0, sigma, Time, rate )
{
    // set type
    OptionType = "AP";
}
AmericanPut::~AmericanPut( )
{
}



double AmericanPut::getValue()
{
    double currVal;

    binomialtree currOpt((*this));

    return currOpt.findval();
}

double AmericanPut::getPayout(double S, double t)
{
    double testP;
    testP = strike - S;
    if (testP > 0) return testP;
    else return 0;
}

//belowe we have the definition of the binomial tree class and its methods
binomialtree::binomialtree( Option& nowOption )
{

    n = 200;
    size = 0;
    P0 = nowOption.getSpot();
    for( int i = 1; i <= n+1; i++ ) size += i;
    u = exp((nowOption.getVolatility())*sqrt((nowOption.getTime())/n));
    d = 1/u;
    a = exp(nowOption.getRate()*nowOption.getTime()/n);
    q = (a - d)/(u - d);


    Equityprices.resize(size);
    optionvalues.resize(size);
    boundary.resize(n+1);


    for( int i = 0; i <= n; i++ ) {boundary[i]=0;}


    setEquity();
    setoption(nowOption);
    setDelta();
    setGamma();

}
binomialtree::~binomialtree()
{
    //  Clearing pointers handled by vector class
}


void binomialtree::setEquity( void )
{
    int m = 0;
    for( int i = 0; i <= n; i++)
    {
        for( int j = 0; j <= i; j++ )
        {
            Equityprices[m] = P0*pow(u,j)*pow(d,(i-j));
            m++;
        }
    }
}

void binomialtree::setoption( Option& nowOption )
{

    double t_step = nowOption.getTime() / n;
    double t = 0;
    double currP;
    int m = size-1;
    double tracker = n;


    for ( int i = 0; i <= n; i++ )
    {

        currP = Equityprices[m];

        optionvalues[m] = nowOption.getPayout(currP,t);


        if( m < (size-1) )
        {if(optionvalues[m] > 0 && optionvalues[m+1] == 0.0)
            { boundary[n] = currP; }}
        if( m < (size-1) )
        {if(optionvalues[m] == 0 && optionvalues[m+1] > 0.0)
            { boundary[n] = currP;}}


        m--;
    }


    t = t + t_step;

    for( tracker; tracker >= 0; tracker-- )
    {

        bool boundset = true;

        for( int i = 0; i < tracker; i++ )
        {
            currP = Equityprices[m];
            double exCheck;

            exCheck = (q*optionvalues[m+1+tracker]+(1-q)*optionvalues[m+tracker])*exp(-nowOption.getRate()*t_step);

            if( nowOption.getPayout(currP,t) > exCheck )
            {

                optionvalues[m] = nowOption.getPayout(currP,t);

                if(optionvalues[m] > optionvalues[m+1] && boundset == true)
                { boundary[tracker-1] = currP; boundset = false;}
                if(optionvalues[m] > 0 && boundset == true)
                { boundary[tracker-1] = currP;}
            }
            else
            { optionvalues[m] = exCheck; }
            m--;
        }
        t = t + t_step;
    }

}

void binomialtree::setDelta( void )
{
    delta = (optionvalues[2]-optionvalues[1])/(Equityprices[2]-Equityprices[1]);
}

double binomialtree::findval( void )
{
    return optionvalues[0];
}

vector<double> binomialtree::ExerciseBoundary( void )
{
    return boundary;
}

double binomialtree::finddelta( void )
{
    return delta;
}
void binomialtree::setGamma( void )
{
    double h = .5*(P0*u*u-P0*d*d);
    gamma = ((optionvalues[5]-optionvalues[4])/(P0*u*u-P0)-(optionvalues[4]-optionvalues[3])/(P0-P0*d*d))/(h);
}
double binomialtree::findgamma( void )
{
    return gamma;
}



